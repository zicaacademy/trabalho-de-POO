//
//  Trabalho_Final_POOApp.swift
//  Trabalho_Final_POO
//
//  Created by Luiz Felipe on 29/11/23.
//

import SwiftUI

@main
struct Trabalho_Final_POOApp: App {
    

    var body: some Scene {
        WindowGroup {
            HomeView()
        }
        
    }
}
